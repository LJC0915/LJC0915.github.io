import React from "react";
import ReactDom from "react-dom";
import Main from "@components/Main.jsx";
import "bootstrap/dist/css/bootstrap.min.css";

(function() {
  chrome.devtools.inspectedWindow.eval("config", (config, isException) => {
    chrome.devtools.inspectedWindow.eval("version", (version, isException) => {
      ReactDom.render(
        <Main config={config} version={version} />,
        document.querySelector("#root")
      );
    });
  });
})();
