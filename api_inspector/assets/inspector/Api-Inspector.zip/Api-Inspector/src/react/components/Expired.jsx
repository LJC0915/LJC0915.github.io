import React from "react";
import "@css/expired.css";

export default class Expired extends React.Component {
  constructor(props) {
    super(props);
  }

  render() {
    return (
      <div className="wrap">
        <h1 className="warning">
          Expired
          <br />
        </h1>
      </div>
    );
  }
}
