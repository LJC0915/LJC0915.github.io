import React from "react";
import ApiWrapper from "./ApiWrapper.jsx";

export default class ApiList extends React.Component {
  constructor(props) {
    super(props);
  }

  render() {
    const {closeApi, apiArray} = this.props;
    return (
      <div className="container p-3 alert-dark rounded">
        {apiArray.reverse().map((api, index) => (
          <ApiWrapper api={api} key={index} closeApi={closeApi} index={index} length={apiArray.length} />
        ))}
      </div>
    );
  }
}
