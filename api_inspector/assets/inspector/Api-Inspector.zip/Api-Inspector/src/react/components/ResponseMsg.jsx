import React from "react";
import ReactJson from "react-json-view";
import { Collapse, Button, CardBody, Card } from "reactstrap";
import "@css/jsonView.css";

export default class ResponseMsg extends React.Component {
  constructor(props) {
    super(props);
    this.toggle = this.toggle.bind(this);
    this.state = { collapse: false };
  }

  toggle() {
    this.setState({ collapse: !this.state.collapse });
  }

  render() {
    const { body } = this.props;
    return (
      <div>
        <Button
          color="primary"
          onClick={this.toggle}
          style={{ marginBottom: "1rem" }}
        >
          Response Body
        </Button>
        <Collapse isOpen={this.state.collapse}>
          <Card>
            <CardBody>
              <div>
                <ReactJson src={body} />
              </div>
            </CardBody>
          </Card>
        </Collapse>
      </div>
    );
  }
}
