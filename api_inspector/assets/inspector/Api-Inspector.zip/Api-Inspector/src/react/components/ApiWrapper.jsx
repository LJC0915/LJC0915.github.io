import React from "react";
import RequestMsg from "./RequestMsg.jsx";
import ResponseMsg from "./ResponseMsg.jsx";
import {Button} from "reactstrap";

export default class ApiWrapper extends React.Component {
  constructor(props) {
    super(props);
    this.onToggleClose = this.onToggleClose.bind(this);
  }

  onToggleClose() {
    const {index, closeApi} = this.props;
    closeApi(index);
  }

  getApiStatusClass(apiStatus, isGameApi) {
    const statusClass = apiStatus ? (isGameApi ? "alert-primary" : "alert-success") : "alert-danger";
    return statusClass;
  }

  render() {
    const {api, index, length} = this.props;
    const apiIndex = length - index;
    const {getApiStatusClass} = this;
    return (
      <div id={api.apiName} className={`container mt-3 p-3 rounded ${getApiStatusClass(api.apiStatus, api.isGameApi)}`}>
        <h5>
          {apiIndex} - API: {api.apiName}
          <Button close onClick={this.onToggleClose} />
        </h5>
        <RequestMsg body={api.requestBody} />
        <ResponseMsg body={api.responseBody} />
      </div>
    );
  }
}
