import React from "react";
import JumpToApi from "@components/JumpToApi.jsx";
import {PesBase64} from "@core/PesBase64.js";
import {Aes} from "@core/Aes.js";
import ApiList from "@components/ApiList.jsx";
import Expired from "@components/Expired.jsx";
import {deadline} from "@core/deadline.js";

const AdminCall = "adminCallSa";
const AdminCallNoToken = "adminCallSaNoToken";
const pes = new PesBase64();
const aes = new Aes();

const Key = "wioerz&!e99!dio@";
let GMS_API_URL = "";
let GAME_API_URL = "";
let apiArray = [];

function isValuableGameApi(request) {
  return request.url.includes(GAME_API_URL) && request.method !== "OPTIONS";
}

function isValuableGMSApi(request) {
  return request.url.includes(GMS_API_URL);
}

function getGUID(headers) {
  return headers.find((header) => header.name === "guid").value;
}

function getGMS_TOKEN(headers) {
  return headers.find((header) => header.name === "gms-access-token").value;
}

function getGAMEApiName(url) {
  const urlWithoutDomain = url.substring(GAME_API_URL.length).replace("/", "");
  return urlWithoutDomain.substring(0, urlWithoutDomain.indexOf("?"));
}

function getGMSApiNAme(url, requestBody) {
  const urlWithoutDomain = url.substring(GMS_API_URL.length).replace(/\//g, "");
  return isAdminApi(urlWithoutDomain) ? requestBody.functionName : urlWithoutDomain;
}

function isAdminApi(apiName) {
  return apiName === AdminCall || apiName == AdminCallNoToken;
}

function filterTouchApi(apiName) {
  return apiName === "touch";
}

export default class Main extends React.Component {
  constructor(props) {
    super(props);
    const {config} = this.props;
    GMS_API_URL = config.GMS_API_URL || config.GMS2_API_URL + "/";
    GAME_API_URL = config.GAME_API_URL;
    this.onClean = this.onClean.bind(this);
    this.removeApi = this.removeApi.bind(this);
    this.updateApiArray = this.updateApiArray.bind(this);
    this.toggle = this.toggle.bind(this);
    this.state = {
      isOpening: true,
      apiArray: [],
    };

    chrome.devtools.network.onRequestFinished.addListener((request) => {
      if (this.state.isOpening) {
        request.getContent((content) => {
          if (isValuableGameApi(request.request)) {
            const GUID = getGUID(request.request.headers);
            const GMS_TOKE = getGMS_TOKEN(request.request.headers);
            const apiName = getGAMEApiName(request.request.url);
            aes.setSecret(GUID, GMS_TOKE);
            const requestBody = aes.decrypt(decodeURIComponent(request.request.url.substring(request.request.url.indexOf("=") + 1)));
            const responseBody = aes.decrypt(JSON.parse(content).result);
            const apiStatus = responseBody.code === 1;
            const isGameApi = true;
            this.updateApiArray(apiName, apiStatus, requestBody, responseBody, isGameApi);
          }
          if (isValuableGMSApi(request.request)) {
            const requestBody = pes.decrypt(Key, request.request.postData.params[0].value);
            const apiName = getGMSApiNAme(request.request.url, requestBody);

            if (filterTouchApi(apiName)) {
              return;
            }

            const responseBody = pes.decrypt(Key, content);
            const apiStatus = responseBody.code === 1;
            const isGameApi = false;
            this.updateApiArray(apiName, apiStatus, requestBody, responseBody, isGameApi);
          }
        });
      }
    });
  }

  updateApiArray(apiName, apiStatus, requestBody, responseBody, isGameApi) {
    apiArray.push({
      apiName,
      apiStatus,
      requestBody,
      responseBody,
      isGameApi,
    });
    this.setState({apiArray});
  }
  onClean() {
    apiArray = [];
    this.setState({apiArray});
  }

  removeApi(index) {
    apiArray.splice(index, 1);
    this.setState({apiArray});
  }

  getButtonClass(isOpening) {
    const CLASS = isOpening ? "btn-success" : "btn-warning";
    return CLASS;
  }

  toggle() {
    this.setState({isOpening: !this.state.isOpening});
  }

  render() {
    const expiredDays = deadline();
    const isExpired = expiredDays < 0;
    const {getButtonClass, toggle} = this;
    return isExpired ? (
      <Expired />
    ) : (
      <>
        <nav className="site-header sticky-top py-1">
          <div className="container d-flex flex-column flex-md-row justify-content-center">
            <a className="py-2 text-center d-md-inline-block text-success" href="#top">
              version: {this.props.version}
            </a>
          </div>
        </nav>
        <div className="container d-flex justify-content-center align-items-center mt-3 mb-3">
          <div className="container d-flex justify-content-center align-items-center mt-3">
            <JumpToApi apiArray={this.state.apiArray} id="top" />
            <button id="clean" type="button" className="btn btn-danger" onClick={this.onClean}>
              Clean
            </button>
            <button type="button" className={`ml-3 btn ${getButtonClass(this.state.isOpening)}`} onClick={toggle}>
              {this.state.isOpening ? "On" : "Off"}
            </button>
          </div>
        </div>
        <ApiList apiArray={this.state.apiArray} closeApi={this.removeApi} />
      </>
    );
  }
}
