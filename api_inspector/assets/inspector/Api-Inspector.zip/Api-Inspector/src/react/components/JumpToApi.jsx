import React from "react";
import {Dropdown, DropdownToggle, DropdownMenu, DropdownItem} from "reactstrap";

export default class JumpToApi extends React.Component {
  constructor(props) {
    super(props);
    this.toggle = this.toggle.bind(this);
    this.state = {
      dropdownOpen: false,
    };
  }

  toggle() {
    this.setState((prevState) => ({
      dropdownOpen: !prevState.dropdownOpen,
    }));
  }

  render() {
    const {apiArray} = this.props;
    const apiLength = apiArray.length;
    return (
      <Dropdown isOpen={this.state.dropdownOpen} toggle={this.toggle} className={"mr-3"}>
        <DropdownToggle caret className="dropdown btn btn-info">
          Jump to Api
        </DropdownToggle>
        <DropdownMenu>
          {apiArray.map((api, index) => (
            <DropdownItem href={`#${api.apiName}`} className={api.apiStatus ? "" : "alert-danger"} key={index}>
              {apiLength - index} - {api.apiName}
            </DropdownItem>
          ))}
        </DropdownMenu>
      </Dropdown>
    );
  }
}
