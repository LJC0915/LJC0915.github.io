import * as base64 from "base-64";
import { utf8decode, utf8encode } from "./Utf8";
const shiftAry = [
  "0123",
  "0132",
  "0231",
  "0213",
  "0312",
  "0321",
  "1023",
  "1032",
  "1203",
  "1230",
  "1302",
  "1320",
  "2013",
  "2031",
  "2103",
  "2130",
  "2301",
  "2310",
  "3012",
  "3021",
  "3102",
  "3120",
  "3201",
  "3210"
];

export class PesBase64 {
  splitStr(text, len) {
    const strArr = text.split("");
    const arr = [];
    let key = 0;
    for (let i = 0; i < strArr.length; i++) {
      if (i > 0 && i % len === 0) {
        key++;
      }

      if (typeof arr[key] === "undefined") {
        arr[key] = "";
      }

      arr[key] += strArr[i];
    }

    return arr;
  }

  shiftEncodeSite(index, str) {
    const idx = parseInt(index, 10) % shiftAry.length;

    return (
      str[parseInt(shiftAry[idx][0], 10)] +
      str[parseInt(shiftAry[idx][1], 10)] +
      str[parseInt(shiftAry[idx][2], 10)] +
      str[parseInt(shiftAry[idx][3], 10)]
    );
  }

  shiftDecodeSite(index, str) {
    const idx = parseInt(index, 10) % shiftAry.length;

    const retAry = { t0: "", t1: "", t2: "", t3: "" };
    let key = "";
    for (let i = 0; i <= 3; i++) {
      key = "t" + shiftAry[idx][i];
      retAry[key] = str[i];
    }

    return retAry.t0 + retAry.t1 + retAry.t2 + retAry.t3;
  }

  xorEncryption(text, key) {
    let r;
    let rPos;
    let rText = "";

    for (let i = 0; i < text.length; i++) {
      rPos = i % key.length;
      r = String.fromCharCode(text.charCodeAt(i) ^ key.charCodeAt(rPos));
      rText += r;
    }

    return rText;
  }

  base64Encode(text) {
    return base64.encode(text);
  }

  base64Decode(text) {
    return base64.decode(text);
  }

  encrypt(key, text) {
    const strArr = this.splitStr(this.base64Encode(utf8encode(text)), 4);
    const sLen = strArr.length - 1;
    let returnStr = "";
    for (let i = 0; i < strArr.length; i++) {
      if (i !== sLen) {
        returnStr += this.shiftEncodeSite(i, strArr[i]);
      } else {
        returnStr += strArr[i];
      }
    }

    return this.base64Encode(this.xorEncryption(returnStr, key));
  }

  decrypt(key, text) {
    let str = this.base64Decode(text);
    str = this.xorEncryption(str, key);

    const strArr = this.splitStr(str, 4);
    let returnStr = "";
    const sLen = strArr.length - 1;
    for (let i = 0; i < strArr.length; i++) {
      if (i !== sLen) {
        returnStr += this.shiftDecodeSite(i, strArr[i]);
      } else {
        returnStr += strArr[i];
      }
    }

    return JSON.parse(utf8decode(this.base64Decode(returnStr)));
  }
}
