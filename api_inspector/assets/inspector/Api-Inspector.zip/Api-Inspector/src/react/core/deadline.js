export function deadline() {
  var deadline_date = new Date("2019-05-20");
  var current_date = new Date();
  var utc1 = Date.UTC(deadline_date.getFullYear(), deadline_date.getMonth(), deadline_date.getDate());
  var utc2 = Date.UTC(current_date.getFullYear(), current_date.getMonth(), current_date.getDate());
  var days = Math.floor((utc1 - utc2) / (1000 * 60 * 60 * 24));
  return days;
}
