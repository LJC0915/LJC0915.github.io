import * as CryptoJS from "crypto-js";

export class Aes {
  buildSecret(key, nonce) {
    return {
      key,
      nonce
    };
  }

  generateTrimmedSecret(secret) {
    return {
      key: secret.key.slice(-16, secret.key.length),
      nonce: secret.nonce.slice(0, 16)
    };
  }

  setSecret(key, nonce) {
    this.secret = this.buildSecret(key, nonce);
  }

  getSecret() {
    return this.secret;
  }

  encrypt(text) {
    const secret = this.generateTrimmedSecret(this.secret);
    const key128Bit = CryptoJS.enc.Utf8.parse(secret.key);
    const nonce128Bit = CryptoJS.enc.Utf8.parse(secret.nonce);
    return CryptoJS.AES.encrypt(text, key128Bit, {
      iv: nonce128Bit,
      mode: CryptoJS.mode.CBC,
      padding: CryptoJS.pad.Pkcs7
    }).toString();
  }

  decrypt(text) {
    const secret = this.generateTrimmedSecret(this.secret);
    const data = text.replace(/[\n\r]/g, "");
    const key128Bit = CryptoJS.enc.Utf8.parse(secret.key);
    const nonce128Bit = CryptoJS.enc.Utf8.parse(secret.nonce);
    const decrypted = CryptoJS.AES.decrypt(data, key128Bit, {
      iv: nonce128Bit,
      mode: CryptoJS.mode.CBC,
      padding: CryptoJS.pad.Pkcs7
    });
    return JSON.parse(CryptoJS.enc.Utf8.stringify(decrypted).toString());
  }
}
