todo

- [x] clean button
- [x] prettier ui
- [x] quick tag
- [x] filter touch api
- [x] json view
- [x] refactor to react
- [x] back to top
