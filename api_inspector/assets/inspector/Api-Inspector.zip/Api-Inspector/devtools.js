(function() {
  chrome.devtools.inspectedWindow.eval("document.title", function(
    result,
    isException
  ) {
    if (!isException) {
      chrome.devtools.panels.create(
        "_API_",
        "./src/images/logo.png",
        "./src/panel.html",
        function(panel) {
          // code invoked on panel creation
        }
      );
    }
  });
})();
